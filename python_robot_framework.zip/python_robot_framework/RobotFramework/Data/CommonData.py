import time

__author__ = 'xxxx'

class CommonData:

    timestamp = time.strftime("%y%m%d%H%M%S")

    USER_NAME = "xxxx"
    PASSWORD = "xxx"
    BASE_URL = "https://en.wikipedia.org/wiki/Automation"
    BROWSER = "Chrome"

    EMP_FIRST_NAME = "Test"
    EMP_LAST_NAME = "Emp"

    pass
