
"""
__author__ = 'E003890'
Create new class that inherits from Selenium2Library
"""
from SeleniumLibrary import SeleniumLibrary
from robot.api.deco import keyword
from robot.libraries.BuiltIn import BuiltIn

class CustomSeleniumLibrary(SeleniumLibrary):

    @keyword
    def validate_employee_search_results(self, search_by_field, search_text, is_negative_case=False):
        builtIn = BuiltIn()

        RESULT_ROW_LOCATOR = "//tbody/tr[td[text()='" + search_text + "']]/td/input[@type='checkbox']"
        #print("find: ", search_by_field.find("Name"))
        if search_by_field.find("Name") > 0 or search_by_field.find("name") > 0:
            RESULT_ROW_LOCATOR = "//tbody/tr[td[a[text()='" + search_text + "']]]/td/input[@type='checkbox']"

        print("RESULT_ROW_LOCATOR: ", RESULT_ROW_LOCATOR)
        builtIn.log("RESULT_ROW_LOCATOR: "+RESULT_ROW_LOCATOR, html=True)

        result_row_count = self.get_matching_xpath_count(RESULT_ROW_LOCATOR)
        result_row_count = int(result_row_count)

        if is_negative_case:
            if  result_row_count <= 0:
                self.capture_page_screenshot()
                builtIn.log("No result found for the negative search (i.e. Search by Field: " + search_by_field + " and Search Text: " + search_text, html=True)
            else:
                self.capture_page_screenshot()
                builtIn.log("Some result found for the negative search (i.e. Search by Field: " + search_by_field + " and Search Text: " + search_text, level="ERROR", html=True)
                pass
            pass
        else:
            if  result_row_count <= 0:
                self.capture_page_screenshot()
                builtIn.log("No result found for the search (i.e. Search by Field: " + search_by_field + " and Search Text: " + search_text, level="ERROR", html=True)
            else:
                self.capture_page_screenshot()
                builtIn.log("Result found for the search (i.e. Search by Field: " + search_by_field + " and Search Text: " + search_text, html=True)
                pass
        pass
