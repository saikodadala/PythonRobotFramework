import time

__author__ = 'E003890'


class EmployeeInformation:

    PIM_LINK_LOCATOR = "//span[text()='PIM']"

    IFRAME_LOCATOR = "//iframe[@id='rightMenu']"


    # search employee locators
    SEARCH_BY_DROPDOWN_LOCATOR = "//*[label[contains(text(), 'Search By')]]/select"
    SEARCH_FOR_INPUT_LOCATOR = "//*[label[contains(text(), 'Search For')]]/input[@type='text']"
    SEARCH_BUTTON = "//*[label[contains(text(), 'Search For')]]/input[@type='button' and @value='Search']"
    RESET_BUTTON = "//*[@type='button' and @value='Reset']"
    NO_RECORDS_MSG_LOCATOR = "//*[text()='No Records to Display']"

    # add Employee locators
    ADD_BUTTON_LOCATOR = "//*[@type='button' and @value='Add']"
    DELETE_BUTTON_LOCATOR = "//*[@type='button' and @value='Delete']"

    EMPLOYEE_CODE_INPUT_LOCATOR = "//input[@id='txtEmployeeId']"
    FIRST_NAME_INPUT_LOCATOR = "//input[@id='txtEmpFirstName']"
    LAST_NAME_INPUT_LOCATOR = "//input[@id='txtEmpLastName']"
    MIDDLE_NAME_INPUT_LOCATOR = "//input[@id='txtEmpMiddleName']"
    NICK_NAME_INPUT_LOCATOR = "//input[@id='txtEmpNickName']"

    SAVE_BUTTON_LOCATOR = "//*[@type='button' and @value='Save']"

    PERSONAL_DETAILS_HEADER_LOCATOR = "//h2[text()='Personal Details']"

    EMP_DELETE_SUCCESS_MSG_LOCATOR = "//*[text()='Successfully Deleted']"

    timestamp_str = time.strftime("%Y%#m%#d%H%M%S")


    pass
