__author__ = 'E003890'


class HomePage:
    LOGOUT_LINK_LOCATOR = "//a[text()='Logout']"



    pass
