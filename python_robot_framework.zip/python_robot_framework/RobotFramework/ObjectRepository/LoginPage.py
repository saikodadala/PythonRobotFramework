

class LoginPage:
    USER_NAME_LOCATOR = "//tr[td[contains(text(), 'Login Name')]]//input[@type='text']"
    PASSWORD_LOCATOR = "//tr[td[contains(text(), 'Password')]]//input[@type='password']"
    LOGIN_BUTTON_LOCATOR = "//input[@type='Submit' and @value='Login']"
    CLEAR_BUTTON_LOCATOR = "//input[@type='reset' and @value='Clear']"

    pass
